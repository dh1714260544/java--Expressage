package com.bean;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.util.Constant;
import com.util.DBO;

public class ExpressageBean {

	private int id;
    private String phone;
    private String type;
    private String beginTime;
    private Boolean isDeleted;
    private String username;
    private String address;
    private String raddress;
    
	private float money;
    private Boolean istaked;
    
    private int userid;//�������û���id
    
    public Boolean getIstaked() {
		return istaked;
	}
	public void setIstaked(Boolean istaked) {
		this.istaked = istaked;
	}
    public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getImages() {
		return images;
	}
	public void setImages(String images) {
		this.images = images;
	}
	private String images;
    
    
	public float getMoney() {
		return money;
	}
	public void setMoney(float money) {
		this.money = money;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}
	public Boolean getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getRaddress() {
		return raddress;
	}
	public void setRaddress(String raddress) {
		this.raddress = raddress;
	}
	@Override
	public String toString() {
		return "ExpressageBean [address=" + address + ", beginTime="
				+ beginTime + ", id=" + id + ", images=" + images
				+ ", isDeleted=" + isDeleted + ", money=" + money + ", phone="
				+ phone + ", raddress=" + raddress + ", type=" + type
				+ ", userid=" + userid + ", username=" + username + "]";
	}
		
	/**
	 * ������еĿ����Ϣ
	 * @return
	 */
public  ExpressageBean[] getAllExpressage()
{
	    ResultSet rs=null;
		String sql = "select * from t_expressages order by id desc";
		DBO dbo = new DBO();
		List<ExpressageBean> list = new ArrayList<ExpressageBean>();
		dbo.open();
		try{
			rs = dbo.executeQuery(sql);
			while(rs.next())
			{
				list.add(toModel(rs));
			}	
			return (ExpressageBean[]) list.toArray(new ExpressageBean[list.size()]);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			dbo.close();
		}
		return null;
	}
/**
 * ��ͼ�� tomodel
 * @param rs
 * @return
 * @throws SQLException
 */
private ExpressageBean toModel(ResultSet rs) throws SQLException {
	
	ExpressageBean ex=new ExpressageBean();
	ex.setId(rs.getInt("id"));
	ex.setAddress(rs.getString("address"));
	ex.setBeginTime(rs.getString("begintime"));
	ex.setIsDeleted(rs.getBoolean("isDeleted"));
	ex.setPhone(rs.getString("phone"));
	ex.setRaddress(rs.getString("raddress"));
	ex.setUsername(rs.getString("username"));
	ex.setType(rs.getString("type"));
	ex.setImages(rs.getString("images"));
	ex.setMoney(rs.getFloat("money"));
	ex.setUserid(rs.getInt("userid"));
	ex.setIstaked(rs.getBoolean("istaked"));
	

	/**
	 * view��
	 */
	
	return ex;
	
}
/*
 * cBean.comUp("insert into zc(qcid,qcsj,qcdd,hcsj,hcdd,member,pic) " +
					"values('"+id+"','"+qcsj+"','"+qcdd+"','"+hcsj+"','"+hcdd+"','"+member+"','"+path+"/"+file.getFileName()+"')");
 */
/**
 * 
 * ����һ�������Ϣ
 */
public int addExpressage(String username,String type,String address,String raddress,
		String images,String phone,String begintime,float money,int userid){
	
	
String sql="insert into t_expressages ( username, type, address, " +
			"raddress, begintime," +
			"images, phone,money,userid,isDeleted,istaked)" +
			" values('"+username+"','"+type+"','"+address+"','"+raddress+"'," +
					"'"+begintime+"','"+images+"'," +
					"'"+phone+"','"+money+"','"+userid+"',0,0) ";
	
	DBO dbo = new DBO();
	dbo.open();
	try{
		int i = dbo.executeUpdate(sql);
		if(i == 1)
			return Constant.SUCCESS;
		else
			return Constant.SYSTEM_ERROR;
	}catch(Exception e){
		e.printStackTrace();
		return Constant.SYSTEM_ERROR;
	}finally{
		dbo.close();
	}
}
/**
 * ����һ�������Ϣ
 * @param sql
 * @return 
 * @return
 */
public int updateExpressageByid(int id, String username, String phone,
String type, String money, String begintime, String address,String raddress)
{	
	DBO dbo = new DBO();
	dbo.open();
	try{
		int i = dbo.executeUpdate("update t_expressages set  username='"+username+
				"',phone='"+phone+"',type='"+type+"',money='"+money+"',address='"+address+
				"',raddress='"+raddress+
				"',begintime='"+begintime+
				"' where id='"+id+"'"+"and istaked =0");
		if(i == 1){
			return Constant.SUCCESS;
		}
		else{
			return Constant.SYSTEM_ERROR;
		}
	}catch(Exception e){
		e.printStackTrace();
		return Constant.SYSTEM_ERROR;
	}finally{
		dbo.close();
	}
}
/**
 * ����session���id��ȡ��ǰ�û�������������Ϣ
 * @param userid2
 * @return
 */
public ExpressageBean[] getAllByUserId(int userid2) {

    ResultSet rs=null;
	String sql = "select * from t_expressages where userid ='"+userid2+"'order by id desc";
	DBO dbo = new DBO();
	List list = new ArrayList();
	dbo.open();
	try{
		rs = dbo.executeQuery(sql);
		while(rs.next())
		{
			list.add(toModel(rs));
		}	
//	��ʽת��	return list.toArray(new MessageDTO[list.size()]);
		return (ExpressageBean[]) list.toArray(new ExpressageBean[list.size()]);
	}catch(Exception e){
		e.printStackTrace();
	}finally{
		dbo.close();
	}
	return null;
}
/**
 * ���һ����ݵ�������Ϣ
 * @param userid
 * @return
 */
public ExpressageBean getOneByUserId(int  id) {
	    
	
	    ResultSet rs=null;
		String sql = "select * from t_expressages where id = '"+id+"'";
		DBO dbo = new DBO();
		dbo.open();
		try{
			rs = dbo.executeQuery(sql);
			rs.next();
			return toModel(rs);
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			dbo.close();
		}
		return null;
	
	
	
}
/**
 * ����ȡ
 * ��ɾ��
 * @param id
 */
public int deleteOne(int id) {

	DBO dbo = new DBO();
	dbo.open();
	try{
		int i = dbo.executeUpdate("update t_expressages set isDeleted = 1 where id ='"+id+"'");
		if(i == 1){
			return Constant.SUCCESS;
		}
		else{
			return Constant.SYSTEM_ERROR;
		}
	}catch(Exception e){
		e.printStackTrace();
		return Constant.SYSTEM_ERROR;
	}finally{
		dbo.close();
	}
	
	
	
}
/**
 * ȷ��һ�������Ϣ
 * ��ɾ��
 * @param id
 */
public int becollect(int id) {

	DBO dbo = new DBO();
	dbo.open();
	try{
		int i = dbo.executeUpdate("update t_expressages set istaked = 1 where id ='"+id+"'");
		if(i == 1){
			return Constant.SUCCESS;
		}
		else{
			return Constant.SYSTEM_ERROR;
		}
	}catch(Exception e){
		e.printStackTrace();
		return Constant.SYSTEM_ERROR;
	}finally{
		dbo.close();
	}
	
	
	
}


/**
 * ɾ��һ�������Ϣ  Ӳɾ��
 * @param id2
 * @return
 */

public int deleteOne2(int id) {
	DBO dbo = new DBO();
	dbo.open();
	try{
		int i = dbo.executeUpdate("delete t_expressages  where id ='"+id+"'");
		if(i == 1){
			return Constant.SUCCESS;
		}
		else{
			return Constant.SYSTEM_ERROR;
		}
	}catch(Exception e){
		e.printStackTrace();
		return Constant.SYSTEM_ERROR;
	}finally{
		dbo.close();
	}
}



/**
 * ����
 * @param args
 */
	public static void main(String []args)
	{
	/*
		ExpressageBean ex=new ExpressageBean();
	    ExpressageBean[] exList=ex.getAllExpressage();
        for(ExpressageBean extest:exList)
        {
        	System.out.println(extest.toString());
        	
        }
	  */
		/*
		ExpressageBean ex=new ExpressageBean();
		ex.addExpressage("test", "test", "test","test", "test", "test","2018-2-1", 1.5f, 47);
	    */
		
		/*
		ExpressageBean ex=new ExpressageBean();
	    ExpressageBean[] exList=ex.getAllByUserId(47);
        for(ExpressageBean extest:exList)
        {
        	System.out.println(extest.toString());
        	
        }
		*/
		/*
		ExpressageBean ex=new ExpressageBean();
		ex=ex.getOneByUserId(15);
		System.out.println(ex.toString());
	*/
		/*
		ExpressageBean ex=new ExpressageBean();
		ex.updateExpressageByid(1, "1", "2", "3", "4", "5", "6", "7");
		*/
		
	}
public ExpressageBean[] getExpressageToUser(int userid2) {
	   
	/*
	 * 
	 * select e.* from member m left join t_userToexpressages utp on m.id = utp.userid left join t_expressages e on e.id = utp.expressageid where m.id=47
	 */
	ResultSet rs=null;
		String sql = "select e.* from member m left join  " +
				"t_userToexpressages utp on m.id = utp.userid left join  " +
				"t_expressages e on e.id = utp.expressageid where m.id='"+userid2+"'";
		DBO dbo = new DBO();
		List list = new ArrayList();
		dbo.open();
		try{
			rs = dbo.executeQuery(sql);
			while(rs.next())
			{
				list.add(toModel(rs));
			}	
//		��ʽת��	return list.toArray(new MessageDTO[list.size()]);
			return (ExpressageBean[]) list.toArray(new ExpressageBean[list.size()]);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			dbo.close();
		}
		return null;	
}
public int check(int expressageid) {
	  ResultSet rs=null;
      
		DBO dbo = new DBO();
		dbo.open();
			try {
				rs = dbo.executeQuery("select * from t_expressages where id ='"+expressageid+"'and isDeleted = 0 ");
			if(rs.next()){
					return Constant.SUCCESS;
				}
				else{
					return Constant.SYSTEM_ERROR;
					
				}	}
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 return Constant.SYSTEM_ERROR;
	
}




}
	
	
	
	
